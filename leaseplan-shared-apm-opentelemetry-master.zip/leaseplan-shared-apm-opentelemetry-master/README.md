# LeasePlan.Shared.Apm.OpenTelemetry

LeasePlan Shared Apm OpenTelemetry project
- contains default configuration for OTel implementation

### Usage:

Add the following to the startup code:

```csharp
builder.ConfigureSerilog();
builder.Services.AddTelemetry(builder.Configuration); //Method defined below
```

Add an extension method to the project to configure the telemetry, logging requirements may vary:
```csharp
public static class DependencyInjection
    {
        /// <summary>
        /// Configures OpenTelemetry
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static IServiceCollection AddTelemetry(this IServiceCollection services, IConfiguration configuration)
        {
            var config = new LoggingConfiguration();
            configuration.Bind(nameof(LoggingConfiguration), config);

            var environment = Environment.GetEnvironmentVariable("DD_ENV");
            if (string.IsNullOrEmpty(environment))
            {
                environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            }

            DefaultActivityListener.AddActivityListener(config.ServiceName, environment, Log.Logger);

            services
                .AddOpenTelemetry()
                .ConfigureResource(resource => resource.AddService(config.ServiceName)
                    .AddEnvironmentVariableDetector()
                    .AddTelemetrySdk())
                .WithMetrics(metrics =>
                {
                    metrics
                        .AddAspNetCoreInstrumentation()
                        .AddHttpClientInstrumentation()
                        .AddNpgsqlInstrumentation();

                    metrics.AddOtlpExporter(ConfigureOtlpExporter.Configure);
                })
                .WithTracing(tracing =>
                {
                    tracing
                        .AddAspNetCoreInstrumentation(config =>
                        {
                            config.RecordException = true;
                        })
                        .AddHttpClientInstrumentation(config =>
                            {
                                config.RecordException = true;
                            }
                        )
                        .AddEntityFrameworkCoreInstrumentation()
                        .AddNpgsql();

                    tracing.AddOtlpExporter(ConfigureOtlpExporter.Configure);
                });

            return services;
        }
```

And the following to appsettings:

```json
"LoggingConfiguration": {
    "ServiceName": "your-service-name"
},
"Serilog": {
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft": "Information",
        "System": "Information"
      }
    },
    "Filter": [
      {
        "Name": "ByExcluding",
        "Args": {
          "expression": "SourceContext like 'CorrelationId.CorrelationIdMiddleware'"
        }
      },
      {
        "Name": "ByExcluding",
        "Args": {
          "expression": "SourceContext like 'MicroElements.Swashbuckle.FluentValidation.FluentValidationRules'"
        }
      },
      {
        "Name": "ByExcluding",
        "Args": {
          "expression": "RequestPath like '%/HealthZ'"
        }
      }
    ]
  },
```