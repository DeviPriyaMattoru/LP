﻿namespace LeasePlan.Shared.Apm.OpenTelemetry.Configuration
{
    public class LoggingConfiguration
    {
        public string ServiceName { get; set; } = string.Empty;
    }
}