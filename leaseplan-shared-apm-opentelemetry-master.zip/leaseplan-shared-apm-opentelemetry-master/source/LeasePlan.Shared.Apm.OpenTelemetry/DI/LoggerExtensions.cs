using System.Diagnostics.CodeAnalysis;
using LeasePlan.Shared.Apm.OpenTelemetry.Utility.Logging;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Formatting.Json;

namespace LeasePlan.Shared.Apm.OpenTelemetry.DI;

[ExcludeFromCodeCoverage]
public static class LoggerExtensions
{
    public static IHostBuilder ConfigureSerilog(this IHostBuilder hostBuilder)
    {
        hostBuilder.UseSerilog(Configure);

        return hostBuilder;
    }

    private static void Configure(HostBuilderContext context, LoggerConfiguration loggerConfiguration)
    {
        var builder = loggerConfiguration.ReadFrom
            .Configuration(context.Configuration);

        builder.Filter.ByExcluding(c => c.Properties.Any(p => p.Value.ToString().Contains("healthz", StringComparison.OrdinalIgnoreCase)))
            .WriteTo.Console(new JsonFormatter(renderMessage: true))
            .Enrich.FromLogContext()
            .Enrich.With<DatadogTracingEnricher>();
    }
}