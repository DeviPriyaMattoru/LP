﻿using LeasePlan.Shared.Apm.OpenTelemetry.Constants;
using OpenTelemetry.Exporter;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.DI
{
    [ExcludeFromCodeCoverage]
    public static class ConfigureOtlpExporter
    {
        public static void Configure(OtlpExporterOptions cfg)
        {
            string? environmentVariable = Environment.GetEnvironmentVariable(variable: DiagnosticsConfig.OTelUrlVariableName);
            if (string.IsNullOrEmpty(environmentVariable))
                return;
            cfg.Endpoint = new Uri(environmentVariable);
        }
    }
}