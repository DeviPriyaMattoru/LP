﻿using LeasePlan.Shared.Apm.OpenTelemetry.Constants;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;

namespace LeasePlan.Shared.Apm.OpenTelemetry.DI;

[ExcludeFromCodeCoverage]
public static class HttpClientActivityEnricher
{
    public static void EnrichClientTrace(Activity activity, HttpResponseMessage response)
    {
        activity.AddTag(TagConstants.ErrorResponse, new
        {
            response.StatusCode,
            Reason = response.ReasonPhrase
        });
    }
}