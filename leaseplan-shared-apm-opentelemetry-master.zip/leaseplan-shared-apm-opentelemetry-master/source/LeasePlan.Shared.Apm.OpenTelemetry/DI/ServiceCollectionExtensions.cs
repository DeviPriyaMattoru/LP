﻿using LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;
using LeasePlan.Shared.Apm.OpenTelemetry.Utility.TraceabilityHeaders;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Npgsql;
using OpenTelemetry.Exporter;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using Serilog;
using System;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.DI;

[ExcludeFromCodeCoverage]
public static class ServiceCollectionExtensions
{
    public static void AddOpenTelemetryConfiguration(this IServiceCollection services, params string[] meters)
    {
        services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        services.AddTransient<IHttpBaggageAccessor, HttpBaggageAccessor>();
        services.AddTransient<TraceabilityHeaderPropagationHandler>();

        var serviceName = Environment.GetEnvironmentVariable("DD_SERVICE");
        var environment = Environment.GetEnvironmentVariable("DD_ENV");

        var logger = Log.Logger;

        if (!IsTracingConfigurationValid(serviceName, environment, logger))
        {
            return;
        }

        if (serviceName == null)
        {
            return;
        }

        DefaultActivityListener.AddActivityListener(serviceName, environment, logger);

        var resourceBuilder = ResourceBuilder.CreateDefault()
            .AddService(serviceName: serviceName)
            .AddTelemetrySdk()
            .AddEnvironmentVariableDetector();

        services
            .AddOpenTelemetry()
            .WithTracing(tracerProviderBuilder =>
            {
                tracerProviderBuilder
                    .SetResourceBuilder(resourceBuilder)
                    .AddOtlpExporter(ConfigureOtlExporter)
                    .AddAspNetCoreInstrumentation(config =>
                    {
                        config.Filter = req => !(req.Request.Path.Equals("/health")
                                                 || req.Request.Path.Equals("/healthz")
                                                 || req.Request.Path.Equals("/metrics")
                                                 || req.Request.Path.StartsWithSegments("/swagger"));
                        config.RecordException = true;
                    })
                    .AddHttpClientInstrumentation(config =>
                    {
                        config.RecordException = true;
                        config.EnrichWithHttpResponseMessage = HttpClientActivityEnricher.EnrichClientTrace;
                    })
                    .AddEntityFrameworkCoreInstrumentation(options => options.SetDbStatementForText = true)
                    .AddNServiceBus()
                    .AddNpgsql()
                    .SetErrorStatusOnException();
            })
            .WithMetrics(meterProviderBuilder =>
            {
                meterProviderBuilder
                    .SetResourceBuilder(resourceBuilder)
                    .AddMeter(meters)
                    .AddOtlpExporter((options, readerOptions) =>
                    {
                        ConfigureOtlExporter(options);

                        readerOptions.TemporalityPreference = MetricReaderTemporalityPreference.Delta;
                    })
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation();
            });
    }

    private static void ConfigureOtlExporter(OtlpExporterOptions cfg)
    {
        var endpoint = Environment.GetEnvironmentVariable("OTEL_EXPORTER_OTLP_ENDPOINT");
        if (endpoint != null)
        {
            cfg.Endpoint = new Uri(endpoint);
        }
    }

    private static bool IsTracingConfigurationValid(string? serviceName, string? environment, ILogger logger)
    {
        if (!string.IsNullOrEmpty(serviceName) && !string.IsNullOrEmpty(environment))
        {
            return true;
        }

        logger.Warning("Tracing configuration missing for service: {ServiceName}, env: {Environment}", serviceName,
            environment);

        return false;
    }
}