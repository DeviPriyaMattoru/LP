﻿using OpenTelemetry.Trace;

namespace LeasePlan.Shared.Apm.OpenTelemetry.DI;

public static class TracerProviderBuilderExtensions
{
    /// <summary>
    /// Subscribes to the Npgsql activity source to enable OpenTelemetry tracing.
    /// </summary>
    public static TracerProviderBuilder AddNServiceBus(this TracerProviderBuilder builder)
    {
        return builder.AddSource("NServiceBus.*");
    }
}