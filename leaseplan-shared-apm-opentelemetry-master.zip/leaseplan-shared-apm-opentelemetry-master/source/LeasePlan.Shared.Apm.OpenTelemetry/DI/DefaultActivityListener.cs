﻿using LeasePlan.Shared.Apm.OpenTelemetry.Constants;
using Serilog;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.DI;

[ExcludeFromCodeCoverage]
public static class DefaultActivityListener
{
    public static void AddActivityListener(string service, string? environment, ILogger logger)
    {
        if (environment == null)
        {
            logger.Warning("Tracing environment is not defined");
            return;
        }
        var listener = new ActivityListener
        {
            ActivityStarted = activity =>
            {
                activity.AddTag(TagConstants.Environment, environment);
                activity.AddTag(TagConstants.Service, service);
            },
            ShouldListenTo = _ => true,
            ActivityStopped = activity =>
            {
                foreach (var (key, value) in activity.Baggage) activity.AddTag(key, value);
            }
        };
        ActivitySource.AddActivityListener(listener);
    }
}