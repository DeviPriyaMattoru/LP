﻿using Serilog.Core;
using Serilog.Events;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.Logging;

[ExcludeFromCodeCoverage]
public class DatadogTracingEnricher : ILogEventEnricher
{
    private const string TracePropertyName = "dd_trace_id";
    private const string SpanPropertyName = "dd_span_id";

    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        var currentActivity = Activity.Current;
        if (currentActivity == null)
            return;

        var stringTraceId = currentActivity.TraceId.ToString();
        var stringSpanId = currentActivity.SpanId.ToString();

        var ddTraceId = Convert.ToUInt64(stringTraceId[16..], 16).ToString();
        var ddSpanId = Convert.ToUInt64(stringSpanId, 16).ToString();

        logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty(TracePropertyName, ddTraceId));
        logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty(SpanPropertyName, ddSpanId));

        foreach (var (key, value) in currentActivity.Baggage)
            logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty(key, value));
    }
}