﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using LeasePlan.Shared.Apm.OpenTelemetry.Constants;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.TraceabilityHeaders;

/// <summary>
/// Will start a new business process, updating the traceability headers with new values
/// Header values are added/updated to Activity.Baggage in the TelemetryMiddleware
/// For this to work, make sure the app.UseMiddleware&lt;TelemetryMiddleware&gt;(); is called
/// after app.UseRouting(); in the Startup.cs
/// </summary>
[ExcludeFromCodeCoverage]
[AttributeUsage(AttributeTargets.Method)]
public class StartsNewBusinessProcessInstanceAttribute : TraceabilityHeaderAttribute
{
    private readonly string _businessProcessName;
    private readonly string _businessProcessInstanceIdValue = Guid.NewGuid().ToString();

    public StartsNewBusinessProcessInstanceAttribute(string businessProcessName)
    {
        _businessProcessName = businessProcessName;
    }

    public override IEnumerable<(string tag, string value)> GetTraceabilityHeaders()
    {
        yield return (TagConstants.BusinessProcessName, _businessProcessName);
        yield return (TagConstants.BusinessProcessInstanceId, _businessProcessInstanceIdValue);
    }
}

/// <summary>
/// Will start a new business process origin, updating the traceability header with a new value
/// The Header value is added/updated to Activity.Baggage in the TelemetryMiddleware
/// For this to work, make sure the app.UseMiddleware&lt;TelemetryMiddleware&gt;(); is called
/// after app.UseRouting(); in the Startup.cs
/// </summary>
[ExcludeFromCodeCoverage]
[AttributeUsage(AttributeTargets.Method)]
public class StartsNewBusinessProcessOriginAttribute : TraceabilityHeaderAttribute
{
    private readonly string _businessProcessOriginIdValue = Guid.NewGuid().ToString();

    public override IEnumerable<(string tag, string value)> GetTraceabilityHeaders()
    {
        yield return (TagConstants.BusinessProcessOriginId, _businessProcessOriginIdValue);
    }
}

public abstract class TraceabilityHeaderAttribute : Attribute
{
    public abstract IEnumerable<(string tag, string value)> GetTraceabilityHeaders();
}
