﻿using System.Diagnostics;
using LeasePlan.Shared.Apm.OpenTelemetry.Constants;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.TraceabilityHeaders;

/// <summary>
/// Adds the traceability headers to the outgoing request
/// Add to the HttpClient by calling IHttpClientBuilder.AddHttpMessageHandler&lt;TraceabilityHeaderPropagationHandler&gt;()
/// 
/// </summary>
public class TraceabilityHeaderPropagationHandler : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        var activity = Activity.Current;

        if (activity == null) return base.SendAsync(request, cancellationToken);

        request.Headers.Add(TagConstants.BusinessProcessOriginId,
            activity.GetBaggageItem(TagConstants.BusinessProcessOriginId));
        request.Headers.Add(TagConstants.BusinessProcessInstanceId,
            activity.GetBaggageItem(TagConstants.BusinessProcessInstanceId));
        request.Headers.Add(TagConstants.BusinessProcessName,
            activity.GetBaggageItem(TagConstants.BusinessProcessName));

        return base.SendAsync(request, cancellationToken);
    }
}