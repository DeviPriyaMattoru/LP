﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

/// <summary>
/// Add baggage to current tracing context
/// </summary>
[ExcludeFromCodeCoverage]
[AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
public class TelemetryAttribute : Attribute
{
    public string PropertyName { get; }

    public string Parameter { get; }

    public DataSource DataSource { get; }

    public TelemetryAttribute(string propertyName, string parameter, DataSource dataSource)
    {
        PropertyName = propertyName;
        Parameter = parameter;
        DataSource = dataSource;
    }
}

public enum DataSource
{
    Header = 1,
    Query = 2,
    Route = 3
}