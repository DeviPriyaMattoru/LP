﻿using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

internal static class HttpContextExtensions
{
    public static Activity? GetRequestActivity(this HttpContext httpContext) => httpContext.Features.Get<IHttpActivityFeature>()?.Activity;
}