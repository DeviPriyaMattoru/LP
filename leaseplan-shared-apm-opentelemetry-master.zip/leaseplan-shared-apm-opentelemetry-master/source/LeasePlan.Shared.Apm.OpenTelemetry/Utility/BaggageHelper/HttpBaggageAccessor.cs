using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

[ExcludeFromCodeCoverage]
internal class HttpBaggageAccessor : IHttpBaggageAccessor
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public HttpBaggageAccessor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public void AddToBaggage(string key, string? value)
    {
        var currentActivity = CurrentActivity;

        if (currentActivity is not null && currentActivity.GetBaggageItem(key) is null)
        {
            currentActivity.AddBaggage(key, value);
        }
    }

    public Activity? CurrentActivity => _httpContextAccessor.HttpContext?.GetRequestActivity();
}