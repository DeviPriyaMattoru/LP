using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using LeasePlan.Shared.Apm.OpenTelemetry.Constants;
using LeasePlan.Shared.Apm.OpenTelemetry.Utility.TraceabilityHeaders;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

[ExcludeFromCodeCoverage]
public class TelemetryMiddleware
{
    private readonly RequestDelegate _next;

    public TelemetryMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        SetBaggageProperties(context);

        await _next(context);
    }

    private void SetBaggageProperties(HttpContext context)
    {
        var activity = context.GetRequestActivity();

        foreach (var (tag, value) in ExtractBaggageProperties(context))
        {
            activity?.SetBaggage(tag, value);
        }
    }

    private IEnumerable<(string tag, string value)> ExtractBaggageProperties(HttpContext context)
    {
        if (context.Request.Headers.TryGetValue(TagConstants.CorrelationId, out var correlationId))
        {
            yield return (TagConstants.CorrelationId, correlationId);
        }

        var traceabilityHeaders = context.Request.Headers
            .Where(h => h.Key.StartsWith("business-", StringComparison.OrdinalIgnoreCase)
                        || h.Key.StartsWith("ng-", StringComparison.OrdinalIgnoreCase));

        foreach (var (key, value) in traceabilityHeaders)
        {
            yield return (key, value);
            Trace.WriteLine($"Added {key} to baggage with value {value}");
        }

        var endpoint = context.GetEndpoint();
        var traceabilityHeaderAttributes = endpoint?.Metadata.GetOrderedMetadata<TraceabilityHeaderAttribute>() ??
                                           Array.Empty<TraceabilityHeaderAttribute>();

        foreach (var traceabilityHeader in
                 traceabilityHeaderAttributes.SelectMany(a => a.GetTraceabilityHeaders()))
        {
            yield return traceabilityHeader;
        }

        // TODO: TelemetryAttribute is not used and should be considered for deprecation in favor of the AddToBaggageAttribute
        // Then below code can be removed
        var telemetryAttributes = endpoint?.Metadata.GetOrderedMetadata<TelemetryAttribute>();

        if (telemetryAttributes is null)
        {
            yield break;
        }

        foreach (var telemetryAttribute in telemetryAttributes)
        {
            var parameter = telemetryAttribute.Parameter;

            string? data = telemetryAttribute.DataSource switch
            {
                DataSource.Query => context.Request.Query[parameter],
                DataSource.Header => context.Request.Headers[parameter],
                DataSource.Route => context.Request.RouteValues[parameter]?.ToString(),
                _ => null
            };

            if (!string.IsNullOrEmpty(data))
            {
                yield return (telemetryAttribute.PropertyName, data);
            }
        }
    }
}