﻿using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Reflection;
using System;
using System.Linq;
using System.Diagnostics.CodeAnalysis;
using System.Collections;
using System.Threading;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

[ExcludeFromCodeCoverage]
public class AddToBaggageFilter : ActionFilterAttribute
{
    private readonly IHttpBaggageAccessor _baggageAccessor;
    private readonly ILogger<AddToBaggageFilter> _logger;

    public AddToBaggageFilter(IHttpBaggageAccessor baggageAccessor, ILogger<AddToBaggageFilter> logger)
    {
        _baggageAccessor = baggageAccessor;
        _logger = logger;
    }

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        try
        {
            foreach (var parameter in GetParameterInfo(context))
            {
                context.ActionArguments.TryGetValue(parameter.Name!, out var parameterValue);

                if (parameterValue == null) continue;

                var baggageValues = FindBaggageValues(parameter, parameterValue);

                foreach (var (tag, baggageValue) in baggageValues)
                    _baggageAccessor.AddToBaggage(tag, baggageValue);
            }
        }
        catch (Exception e)
        {
            _logger.LogError(e, "Error while adding value to baggage");
        }
        finally
        {
            base.OnActionExecuting(context);
        }
    }

    private static IEnumerable<ParameterInfo> GetParameterInfo(ActionExecutingContext context)
    {
        return ((ControllerActionDescriptor)context.ActionDescriptor).MethodInfo
            .GetParameters().Where(p => p.Name != null && !p.ParameterType.IsAssignableTo(typeof(CancellationToken)));
    }

    private static List<(string, string)> FindBaggageValues(ParameterInfo parameter, object parameterValue)
    {
        var parameterAttribute = parameter.GetCustomAttribute<AddToBaggageAttribute>();

        if (parameterAttribute != null)
            return new List<(string, string)> { (parameterAttribute.Tag, parameterValue.ToString()!) };

        var baggageValues = new List<(string Tag, string Value)>();
        AddBaggageValues(parameterValue, baggageValues);

        return baggageValues;
    }

    private static void AddBaggageValues(object parameterValue,
        ICollection<(string Tag, string Value)> baggageValues)
    {
        var properties = parameterValue.GetType().GetProperties();

        foreach (var property in properties)
        {
            var propertyAttribute = property.GetCustomAttribute<AddToBaggageAttribute>();

            if (propertyAttribute == null)
            {
                // Filter out properties that are not interesting to inspect for attributes
                if (property.PropertyType.IsPrimitive ||
                    property.PropertyType.Namespace == typeof(string).Namespace ||
                    property.PropertyType.IsEnum ||
                    typeof(IEnumerable).IsAssignableFrom(property.PropertyType)) continue;

                var value = property.GetValue(parameterValue, null);
                if (value != null)
                {
                    AddBaggageValues(value, baggageValues);
                }
            }
            else
            {
                var value = property.GetValue(parameterValue, null);

                if (value == null) continue;

                var stringValue = value as string ?? value.ToString();

                baggageValues.Add((propertyAttribute.Tag, stringValue!));
            }
        }
    }
}
