﻿using System.Diagnostics;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

public interface IHttpBaggageAccessor
{
    public void AddToBaggage(string key, string? value);

    public Activity? CurrentActivity { get; }
}