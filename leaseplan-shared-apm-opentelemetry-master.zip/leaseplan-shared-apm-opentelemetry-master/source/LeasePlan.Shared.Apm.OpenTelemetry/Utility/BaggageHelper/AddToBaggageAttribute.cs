﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;

/// <summary>
/// Add Property or Parameter Value to baggage under the provided Tag
/// To be used in conjunction with AddToBaggageFilter
/// For tag values, use the TagConstants provided in this package where possible
/// </summary>
[ExcludeFromCodeCoverage]
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
public class AddToBaggageAttribute : Attribute
{
    public AddToBaggageAttribute(string tag)
    {
        Tag = tag;
    }

    public string Tag { get; }
}