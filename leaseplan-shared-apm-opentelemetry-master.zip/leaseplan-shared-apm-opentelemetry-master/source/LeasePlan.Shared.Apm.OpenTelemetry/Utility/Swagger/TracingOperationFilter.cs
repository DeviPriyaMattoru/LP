﻿using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Utility.Swagger;

[ExcludeFromCodeCoverage]
public class TracingOperationFilter : IOperationFilter
{
    private const string CorrelationIdHeader = "correlation-id";
    private const string TraceparentHeader = "traceparent";
    private const string TraceEntityHeader = "ng-trace-entity";

    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        if (operation.Parameters == null)
            operation.Parameters = new List<OpenApiParameter>();

        AddCorrelationIdParameter(operation);

        AddTraceparentParameter(operation);

        AddTraceEntityParameter(operation);

        AddTraceEntityParameter(operation);

        AddCorrelationIdResponseHeader(operation);
    }

    private static void AddCorrelationIdParameter(OpenApiOperation operation)
    {
        var headerParameter = new OpenApiParameter
        {
            In = ParameterLocation.Header,
            Name = CorrelationIdHeader,
            Description = "Unique identifier attached to request and responses as header that allows reference to a particular transaction or chain of transactions. Based on UUID conforming to RFC 4122 - https://datatracker.ietf.org/doc/html/rfc4122",
            Schema = new OpenApiSchema
            {
                Type = "string",
                Format = "uuid",
                Example = new OpenApiString(Guid.NewGuid().ToString())
            },
            Required = true
        };

        operation.Parameters.Add(headerParameter);
    }

    private static void AddTraceparentParameter(OpenApiOperation operation)
    {
        var headerParameter = new OpenApiParameter
        {
            In = ParameterLocation.Header,
            Name = TraceparentHeader,
            Description = "Traceparent HTTP header field identifies the incoming request in a tracing system. Conforming to OpenTelemetry (OTel) Trace Context",
            Schema = new OpenApiSchema
            {
                Type = "string"
            },
            Required = false
        };

        operation.Parameters.Add(headerParameter);
    }

    private static void AddTraceEntityParameter(OpenApiOperation operation)
    {
        var headerParameter = new OpenApiParameter
        {
            In = ParameterLocation.Header,
            Name = TraceEntityHeader,
            Description = "The ng-trace-entity HTTP header gets the entity code from incoming request and provides it for OpenTelemetry (OTel) Trace Context.",
            Schema = new OpenApiSchema
            {
                Type = "string"
            },
            Required = false
        };

        operation.Parameters.Add(headerParameter);
    }

    private static void AddCorrelationIdResponseHeader(OpenApiOperation operation)
    {
        foreach (var entry in operation.Responses)
            entry.Value.Headers[CorrelationIdHeader] = new OpenApiHeader
            {
                Schema = new OpenApiSchema { Type = "string", Format = "uuid" }
            };
    }
}