﻿using OpenTelemetry.Trace;

namespace LeasePlan.Shared.Apm.OpenTelemetry.Handlers
{
    public class TracingHttpRequestHandler : DelegatingHandler
    {
        private readonly Tracer _tracer;
        private readonly string _serviceName;
        private readonly string _operationName;
        private readonly bool _propagateTraceInformation;

        public TracingHttpRequestHandler(TracerProvider tracerProvider, string serviceName, string operationName, bool propagateTraceInformation = true)
        {
            _tracer = tracerProvider.GetTracer(serviceName);
            _serviceName = serviceName;
            _operationName = operationName;
            _propagateTraceInformation = propagateTraceInformation;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if (_tracer == null)
            {
                return await base.SendAsync(request, cancellationToken);
            }

            using var span = _tracer.StartActiveSpan(_operationName ?? _serviceName, SpanKind.Client);
            span.SetAttribute("resource.name", request.RequestUri?.AbsolutePath);
            span.SetAttribute("service.name", _serviceName);
            span.SetAttribute("span.type", "http");
            span.SetAttribute("http.method", request.Method.Method);
            span.SetAttribute("http.path", request.RequestUri?.AbsolutePath);
            span.SetAttribute("http.query", request.RequestUri?.Query);

            using (var childSpan = _tracer.StartActiveSpan("http.response"))
            {
                if (_propagateTraceInformation)
                {
                    request.Headers.Add("x-datadog-parent-id", childSpan.Context.SpanId.ToString());
                    request.Headers.Add("x-datadog-trace-id", childSpan.Context.TraceId.ToString());
                }
                try
                {
                    HttpResponseMessage httpResponseMessage = await base.SendAsync(request, cancellationToken);
                    span.SetAttribute("http.status_code", httpResponseMessage.StatusCode.ToString());
                    return httpResponseMessage;
                }
                catch (Exception ex)
                {
                    childSpan.RecordException(ex);
                    throw;
                }
            }
        }
    }
}