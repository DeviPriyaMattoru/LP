namespace LeasePlan.Shared.Apm.OpenTelemetry.Constants
{
    public static class DiagnosticsConfig
    {
        public const string OTelUrlVariableName = "OTEL_EXPORTER_OTLP_ENDPOINT";
    }
}