﻿namespace LeasePlan.Shared.Apm.OpenTelemetry.Constants;

public static class TagConstants
{
    public const string ILAN = "ILAN";
    public const string USGC = "USGC";
    public const string USVC = "USVC";
    public const string EntityCode = "Entity";

    public const string Environment = "env";
    public const string CorrelationId = "correlation-id";
    public const string Version = "version";
    public const string Service = "service";
    public const string ErrorResponse = "ErrorResponse";

    public const string BusinessProcessOriginId = "business-process-origin-id";
    public const string BusinessProcessName = "business-process-name";
    public const string BusinessProcessInstanceId = "business-process-instance-id";
}