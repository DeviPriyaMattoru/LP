﻿using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using LeasePlan.Shared.Apm.OpenTelemetry.Constants;
using LeasePlan.Shared.Apm.OpenTelemetry.Utility.TraceabilityHeaders;
using Xunit;

namespace LeasePlan.Shared.Apm.OpenTelemetry.UnitTests;

public class TraceabilityHeaderPropagationHandlerTests
{
    private class MockHttpMessageHandler : HttpMessageHandler
    {
        public HttpRequestMessage LastRequest { get; private set; }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            LastRequest = request;
            return await Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK));
        }
    }

    [Fact]
    public async Task TraceabilityHeadersAreAdded()
    {
        var mockHandler = new MockHttpMessageHandler();

        var traceabilityHandler = new TraceabilityHeaderPropagationHandler
        {
            InnerHandler = mockHandler
        };

        var httpClient = new HttpClient(traceabilityHandler);

        // Set up Activity with baggage items
        var activity = new Activity("Test");
        activity.AddBaggage(TagConstants.BusinessProcessOriginId, "TestOriginId");
        activity.AddBaggage(TagConstants.BusinessProcessInstanceId, "TestId");
        activity.AddBaggage(TagConstants.BusinessProcessName, "TestName");
        activity.Start();

        await httpClient.GetAsync("http://example.com");

        activity.Stop();

        // Verify headers were added to the outgoing request
        Assert.NotNull(mockHandler.LastRequest);
        Assert.True(mockHandler.LastRequest.Headers.Contains(TagConstants.BusinessProcessOriginId));
        Assert.True(mockHandler.LastRequest.Headers.Contains(TagConstants.BusinessProcessInstanceId));
        Assert.True(mockHandler.LastRequest.Headers.Contains(TagConstants.BusinessProcessName));
    }
}
