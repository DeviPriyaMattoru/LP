using System.Diagnostics;
using System.Text;

namespace LeasePlan.Shared.Apm.OpenTelemetry.UnitTests.Helpers;

public class TestTraceListener : TraceListener
{
    private readonly StringBuilder _capturedOutput = new StringBuilder();

    public override void Write(string message)
    {
        _capturedOutput.Append(message);
    }

    public override void WriteLine(string message)
    {
        _capturedOutput.AppendLine(message);
    }

    public string GetCapturedOutput()
    {
        return _capturedOutput.ToString();
    }
}