#nullable enable

using LeasePlan.Shared.Apm.OpenTelemetry.DI;
using LeasePlan.Shared.Apm.OpenTelemetry.UnitTests.Helpers;
using LeasePlan.Shared.Apm.OpenTelemetry.Utility.BaggageHelper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using LeasePlan.Shared.Apm.OpenTelemetry.Utility.TraceabilityHeaders;
using Microsoft.AspNetCore.Http;
using Xunit;
using Microsoft.AspNetCore.Http.Features;

namespace LeasePlan.Shared.Apm.OpenTelemetry.UnitTests;

public class HeaderEnrichmentTests
{
    [Theory]
    [InlineData("GET", "ng-entity-code", "LPUK", "LPUK")]
    [InlineData("POST", "ng-entity-code", "LPPT", "LPPT")]
    [InlineData("PUT", "ng-entity-code", "LPNL", "LPNL")]
    [InlineData("DELETE", "ng-entity-code", "LPPT", "LPPT")]
    [InlineData("PATCH", "ng-entity-code", "LPPT", "LPPT")]
    [InlineData("GET", "business-whatever", "Test", "Test")]
    [InlineData("POST", "business-some-other", "OtherTest", "OtherTest")]
    [InlineData("PUT", "business-process-id", "a5b9ed2f-f941-45b7-8d9c-b92f1ae74aa8",
        "a5b9ed2f-f941-45b7-8d9c-b92f1ae74aa8")]
    [InlineData("DELETE", "business-process-name", "service-activation", "service-activation")]
    [InlineData("PATCH", "business-process-origin-id", "e7aadb67-63b7-4c35-83c6-1db2adcf4ead",
        "e7aadb67-63b7-4c35-83c6-1db2adcf4ead")]
    [InlineData("GET", "ang-entity-code", "LPUK", null)]
    [InlineData("POST", "x", "LPPT", null)]
    public async Task OpenTelemetryMiddlewareTest_HeaderEnrichment(string method, string header, string headerValue,
        string? expected)
    {
        var traceListener = new TestTraceListener();
        Trace.Listeners.Add(traceListener);
        using var host = await new HostBuilder()
            .ConfigureWebHost(webBuilder =>
            {
                webBuilder
                    .UseTestServer()
                    .ConfigureServices(services =>
                    {
                        services.AddHttpContextAccessor();
                        services.AddHealthChecks();
                        services.AddOpenTelemetryConfiguration();
                    })
                    .Configure(app => { app.UseMiddleware<TelemetryMiddleware>(); });
            })
            .StartAsync();

        var client = host.GetTestClient();

        client.DefaultRequestHeaders.Add(header, headerValue);
        HttpResponseMessage response;
        var url = "/";
        var content = new StringContent(string.Empty);
        switch (method)
        {
            case "GET":
                response = await client.GetAsync(url);
                break;

            case "POST":
                response = await client.PostAsync(url, content);
                break;

            case "PUT":
                response = await client.PutAsync(url, content);
                break;

            case "DELETE":
                response = await client.DeleteAsync(url);
                break;

            case "PATCH":
                response = await client.PatchAsync(url, content);
                break;

            default:
                throw new ArgumentException("Invalid HTTP method.");
        }

        // Assert
        Trace.Flush();
        Trace.Listeners.Remove(traceListener);

        var capturedOutput = traceListener.GetCapturedOutput();
        Assert.NotEqual(HttpStatusCode.Found, response.StatusCode);
        Assert.Contains(expected ?? "", capturedOutput);
    }


    [Fact]
    public async Task OpenTelemetryMiddlewareTest_TraceabilityAttributes()
    {
        var builder = WebApplication.CreateBuilder();

        builder.WebHost.UseTestServer();

        builder.Services.AddOpenTelemetryConfiguration();

        var app = builder.Build();
        app.UseMiddleware<TelemetryMiddleware>();
        const string startNewBusinessProcessUrl = "/startnewbusinessprocess";
        const string startNewBusinessProcessOriginUrl = "/startnewbusinessprocessororigin";

        app.MapPost(startNewBusinessProcessUrl, ControllerMethodThatStartsNewBusinessProcess);
        app.MapPost(startNewBusinessProcessOriginUrl, ControllerMethodThatStartsNewBusinessProcessOrigin);

        await app.StartAsync();

        var client = app.GetTestClient();

        client.DefaultRequestHeaders.Add("business-process-origin-id", "e7aadb67-63b7-4c35-83c6-1db2adcf4ead");
        client.DefaultRequestHeaders.Add("business-process-id", "a5b9ed2f-f941-45b7-8d9c-b92f1ae74aa8");
        client.DefaultRequestHeaders.Add("business-process-name", "BoringOldProcess");

        var content = new StringContent(string.Empty);
        await client.PostAsync(startNewBusinessProcessUrl, content);
        await client.PostAsync(startNewBusinessProcessOriginUrl, content);
    }

    [StartsNewBusinessProcessInstance("MyFancyNewProcess")]
    private Task ControllerMethodThatStartsNewBusinessProcess(HttpContext context)
    {
        var baggage = context.Features.Get<IHttpActivityFeature>()?.Activity.Baggage.ToList()!;
        Assert.Contains(baggage,
            x => x.Key == "business-process-origin-id" && x.Value == "e7aadb67-63b7-4c35-83c6-1db2adcf4ead");
        Assert.Contains(baggage,
            x => x.Key == "business-process-name" && x.Value == "MyFancyNewProcess");
        Assert.DoesNotContain(baggage,
            x => x.Key == "business-process-name" && x.Value == "BoringOldProcess");
        Assert.Contains(baggage,
            x => x.Key == "business-process-instance-id" && Guid.TryParse(x.Value, out _) &&
                 x.Value != "a5b9ed2f-f941-45b7-8d9c-b92f1ae74aa8");

        return Task.CompletedTask;
    }

    [StartsNewBusinessProcessOrigin]
    [StartsNewBusinessProcessInstance("MyFancyNewProcess")]
    private Task ControllerMethodThatStartsNewBusinessProcessOrigin(HttpContext context)
    {
        var baggage = context.Features.Get<IHttpActivityFeature>()?.Activity.Baggage.ToList()!;
        Assert.Contains(baggage,
            x => x.Key == "business-process-origin-id" && Guid.TryParse(x.Value, out _) &&
                 x.Value != "e7aadb67-63b7-4c35-83c6-1db2adcf4ead");
        Assert.Contains(baggage,
            x => x.Key == "business-process-name" && x.Value == "MyFancyNewProcess");
        Assert.DoesNotContain(baggage,
            x => x.Key == "business-process-name" && x.Value == "BoringOldProcess");
        Assert.Contains(baggage,
            x => x.Key == "business-process-instance-id" && Guid.TryParse(x.Value, out _) &&
                 x.Value != "a5b9ed2f-f941-45b7-8d9c-b92f1ae74aa8");

        return Task.CompletedTask;
    }
}

